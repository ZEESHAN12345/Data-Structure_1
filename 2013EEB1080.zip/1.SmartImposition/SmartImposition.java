package ds;

import java.util.*;

public class SmartImposition {                                          //Created a class 'SmartImposition'
	public static void main(String[] args){
		int error;                                                    // A variable 'error' that defines the no. of errors required in the given imposition
		int time;                                                    // A variable 'time' that defines total no. of times the imposition to be printed
	    Scanner m=new Scanner(System.in);
	    System.out.println("Enter the imposition sentence to be repeated:");
		String message=m.nextLine();
		while (true){
		System.out.println("No. of times you want to print");
		time=m.nextInt();
		if (time>0){                                                    //checks if no of impositions to be printed is positive in no.
			break;
		}
		else
			System.out.println("Please input the positive no.");
		}
		while (true){                                               //escapes from the loop
		System.out.println("No. of errors");                       //checks if error is less than or equal to no. of impositions and is postive
		error=m.nextInt();
		if (error<=time && error>0){
			break;
		}
		else
			System.out.println("Errors can't exceed no of impositions");
		}
		Random random=new Random();
		LinkedHashSet<Integer> array= new LinkedHashSet<>();     //created a simple linked hash set to generate random no. 'without repetition' 
			 while (array.size()<error){
				 array.add(random.nextInt(time));
			 }
		int str_index,ac;
		for (int i=0;i<time;i++){
			boolean b=array.contains(i);
				 if (b==true){                                                        //this part of the code does the main job
				 str_index=mess_length(message.length(),message);                    //it takes the random no. generated from the linked hash set
				 ac=randomchar(122,97);                                             //determines the sentence/line no. at which error is required to impose
				 char [] testarray=message.toCharArray();                          //printing the remaining lines without error
				 char ch= (char) ac;
				 testarray[str_index]=ch;
				 
				 for (int j=0;j<message.length();j++){
					 
					 System.out.print(testarray[j]);
				 }
				 System.out.print('\n');
			 }
			
			
		else
				System.out.println(message);
			 
		 }
		m.close();
	}
	
			
public static int randomchar(int max,int min){            //method to generate random no. within some specified limits
	  Random random_char=new Random();
	  return random_char.nextInt((max-min)+1)+min;
  }

 public static int mess_length(int l,String m){       // method to generate random index of the string where error-insertion is required
	  Random r=new Random();
	  while(true){
		  int index=r.nextInt(l);
		  if (Character.isWhitespace(m.charAt(index))==false){
			  return index;
			}
		 
	  }
}
}

