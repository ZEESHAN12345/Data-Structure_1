package ds;

public class student_record {
	private int data;
	 private String stud_id;
	 private int rank;
	 
	 public student_record(int d,String nm,int r){
		this.data=d;
		this.stud_id=nm;
		this.rank=r;
	 }

	public int getData() {                                                             // implemented 'get' method
		return data;
	}

	public void setData(int data) {                                                //implemented 'set' methods//
		this.data = data;                                                                  
	}

	public String getStud_id() {
		return stud_id;
	}

	public void setStud_id(String stud_id) {
		this.stud_id = stud_id;
	}

	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}
     
	public String toString(){
		return stud_id+'\t'+rank+'\0';
	}
}