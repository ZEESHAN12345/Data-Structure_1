package ds;

public class Dnode{                                           //created a class for the 'node' in the same package
	 Object data;
	
	 Dnode previous;                                       //created a previous reference
	 Dnode next;                                          //created a next reference
	 
	 public Dnode(Object d){
		 this.data=d;
		 
	 }
}