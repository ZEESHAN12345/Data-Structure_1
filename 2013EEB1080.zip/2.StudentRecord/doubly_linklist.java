package ds;

import java.util.*;


public class doubly_linklist {                                           //class for links between nodes of the doubly link list
       static Dnode root;
       static Dnode current;
       
       public void addnodes(Object d1){
    	   Dnode dnode = new Dnode(d1);
    	   
    	   if (root==null){
    		   root=dnode;
    		   root.previous=null;
    		   root.next=null;
    	   }
    	   else{
    		   current=root;
    		   while(current.next!=null){
    			   current=current.next;
    		   }
    		   current.next=dnode;
    		   dnode.previous=current;
    		   
    	   }
       }
       
      public void print(){
    	  current=root;
      while(current!=null){
    		  System.out.println(current.data);
    		  current=current.next;
    	  }
      
    	  
      }
      
      public static void main(String[] args){                                 //main function starts from here....
    	  int i,r1;
    	 doubly_linklist list=new doubly_linklist();
    	Scanner m = new Scanner(System.in);
    	 List<student_record> s = new ArrayList<student_record>();
    	 for (int i1=1;i1<=10;i1++){
    		 
    		while (true){
    			
    	 System.out.println("Enter 1 if you wish to input else enter 0 if you wish to stop:");
    	 
    	 i=m.nextInt();
    	 
    	 
    
    	 if (i==1 || i==0){
    		 break;
    	 }
    	 
    	 else{
    		 System.out.println("Please enter either 1 or 0");
    	 }
    		}
    	 if (i==0){
    		 break;
    	 }
    	 else{
    	 System.out.println("Enter Student name:");
    	 Scanner m1 = new Scanner(System.in);
    	 String name=m1.nextLine();
    	 while (true){
    	 System.out.println("Enter Student's rank:");
    	 r1=m.nextInt();
    	 if (r1>0){
    		 break;
    	 }
    	 else
    		 System.out.println("Please Enter possible ranks.");
    	 }
    	 s.add(new student_record(i,name,r1));
    	 Collections.sort(s,new Comparator<student_record>(){

			@Override
			public int compare(student_record p1, student_record p2) {
				if(p1.getRank()>p2.getRank()){                                             //isGreater than comparator
					return 1;
				}
				else if (p1.getRank()==p2.getRank()){                                   //isEqual comparator
					return 0;
				}
				else                                                                 //isLess than comparator
					return -1;
			}
    		 
    	 });
    	 for (student_record s1: s){
    		 list.addnodes(s1);
    	 }
    	 list.print();
    	 }
    	 }
      }
}