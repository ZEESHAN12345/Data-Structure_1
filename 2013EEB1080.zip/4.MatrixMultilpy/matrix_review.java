package ds;

import java.util.*;

public class matrix_review {
	public static void main(String[] args)                                     // main method starts from here...
	  {                                                      
		int [] A={5,10,20,30,40,50};                                         //size of matrix 'n'
		for (int i=0;i<6;i++){                                              
			  System.out.println();
	    	  System.out.println("For n= "+A[i]);
	    	  long totaltime=0;
	    	  for(int j=1;j<=20;j++){                                    //multiplying two randomly generated matrices 20 times for a specified size of matrix 'n' 
	    		  int multiply[][]=new int[A[i]][A[i]];        
	    	      int sum=0;                                          
	    	      int [][] M1=new int [A[i]][A[i]];
	    	      int [][] M2=new int [A[i]][A[i]];
	    	      
	    	      Random r1 = new Random();                          //generating two random matrices
	    		    for(int k=0; k < M1.length; k++){
	    		        for(int l=0; l < M1[i].length; l++)
	    		        {
	    		            M1[k][l] = r1.nextInt(100);
	    		        }
	    		    }
	    		  
	    		  Random r2 = new Random();
	    		    for(int k=0; k < M2.length; k++){
	    		        for(int l=0; l < M2[i].length; l++)
	    		        {
	    		            M2[k][l] = r2.nextInt(100);
	    		        }
	    		    }
	    		    
	    		   long startTime = System.nanoTime();
	    	      for ( int x = 0 ; x < A[i] ; x++ )                                 //multiplication of random matrices
	    	         {
	    	    	   
	    	            for ( int y = 0 ; y < A[i] ; y++ )
	    	            {
	    	            	sum=0;
	    	               for ( int z = 0 ; z < A[i] ; z++ )
	    	               {
	    	                  sum+=M1[x][z]*M2[z][y];
	    	               }
	    	 
	    	               multiply[x][y] = sum;
	    	            }
	    	         }
	    	      long endTime   = System.nanoTime();
	    	      totaltime = totaltime + (endTime - startTime);
	    	  }
			
			totaltime=totaltime/20;                                             //calculating time(in ns) for each given order of 'n'
			System.out.println("The total time taken for 20 multiplications of n="+A[i]+' '+"is"+' '+totaltime+" ns");
	  }
}
}