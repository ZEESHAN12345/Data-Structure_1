package ds;

import java.util.Scanner;

public class recursion {
	public static void main(String[] args){
		Scanner s=new Scanner(System.in);
	    System.out.println("Enter the number of integer elements you want to input:");
	    int n=s.nextInt();
	    int A1[]=new int[n];
	    System.out.println("Successful! Now enter those elements");
	    for(int i=0;i<A1.length;i++){                                                      //input the array A1 to be sorted
	      A1[i]=s.nextInt();
	    }
	 
	    System.out.println("Good go! Now enter the element you want to insert and get rearranged in the existing array of your numbers:");
	                         int k=s.nextInt();
	                         int[] A=new int[n+1];                                   // creating a new array A containing 'k' as first element and rest elements the same as A1
	                         A[0]=k;
	                         for (int i=1;i<n+1;i++)
	                           A[i]=A1[i-1];
	                        
	         s.close();
	                                                           
    int fixed=A[0];                                                            // Quick Sort's partition is used from here to arrange in the required sorting
    int l=1; int r=n;
    while(l<r)
    {
    	while(A[r]>fixed){
            r--;
        }
        while(A[l]<fixed){
            l++;
        }
        if(l<r){
            int temp=A[l];
            A[l]=A[r];
            A[r]=temp;
        }

    }
    System.out.println("The possible outcome can be:");
    for(int i=1;i<n+1;i++)
    System.out.print(A[i]);                                          // printing final sorted array!
}
}
