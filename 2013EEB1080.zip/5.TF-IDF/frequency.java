package ds;

import java.util.*;
import java.io.*;

class MyWord {
	String word = null;
	int[] frequency;
	float idf;
	static int number_of_files;
	int file_number;
	int max_freq = 1;

	void setMax() {
		for (int i : frequency) {
			if (i > max_freq)
				max_freq = i;
		}

	}
}


public class frequency {
	public static float TF( String tt,String[] ddoc, int mf )          // a method to formulate tf statistics value 
	{   float result=0f;
		int f=0;
		for(int i=0;i<ddoc.length;i++)        // calculating frequency of a word in each document
		{
			if(ddoc[i] != null){
			if(ddoc[i].equals(tt))
				f += 1;
			}
		float ff = (float) f;
		float fraction =  (float) (0.5*(ff/mf));
		 result = (float) (0.5 + fraction);
		}
		return result;
	}
	public static Float IDF( String tt,String[][] ddoc, int n )            // a method to formulate tf statistics value 
	{   
		int ndoc=0;
		for( int i=0; i<n;i++){                                         // calculating no of documents in which each of the words occur
			for(int j=0;j<ddoc[i].length;j++){
				if( ddoc[i][j] == null)
					continue;
				if(ddoc[i][j].equals(tt)){
					ndoc++;
				}
				}
		}
		if( ndoc==0)
			ndoc=1;
		float result = (float) Math.log(n/ndoc);
		return  result;
		
	}
	public static void main(String[] argument) {
		String document = "";
		Scanner input=new Scanner(System.in);
		System.out.println("Enter the no of text files you want to input");        // intakes the 'no. of files' that user will direct after this step
		int NoOfFiles=input.nextInt();
		File fo = new File( "k" );
		MyWord.number_of_files = NoOfFiles;                                        //object of a class my word that stores no. of documents user gonna give
		
		File[] fl = fo.listFiles();
		String[][] twodarray = new String[ NoOfFiles ][1000];
		String ttemp = "";
		for (int i = 0; i < fl.length; i++) {
			Scanner s = null;
			ttemp = "";
			try {
			s = new Scanner(new BufferedReader(new FileReader( fl[i].getAbsoluteFile() )));  //getting folder path that contains the document files for this program to run 
			String CurrentLine;
			while ( s.hasNextLine()) {
				CurrentLine = s.nextLine();
				document += CurrentLine;
				document += "\n";
				ttemp = CurrentLine;
				ttemp += "\n";
			}
			document += " MyBreak" + i + "\n";
			ttemp += " MyBreak" + i + "\n";
			}catch (Exception e) {                               //if no file is found at a given path
				a("Path name can not be found!");} 
			finally {
			if (s != null) {
			s.close();
			}
			}
			ttemp = ttemp.toLowerCase();                    //getting rid of case-sensitiveness in the given document
			String[] tempword = ttemp.split(" ");
			String[] tempwords1 =new String[100000];
			ttemp=ttemp.replaceAll("\t"," ");               // replacing 'tab' with 'space'
			int kk = 0;
			for(int ii=0;ii<tempword.length;ii++)          //checking for the following list of words in the document
			{
			if(!tempword[ii].equals("a") && !tempword[ii].equals("an") && !tempword[ii].equals("the") && !tempword[ii].equals("this") && !tempword[ii].equals("that") && !tempword[ii].equals("and") && !tempword[ii].equals("or") && !tempword[ii].equals("is") && !tempword[ii].equals("are") && !tempword[ii].equals("then") && !tempword[ii].equals("there") && !tempword[ii].equals("they") && !tempword[ii].equals("of") && !tempword[ii].equals("on") && !tempword[ii].equals("in") && !tempword[ii].equals("to"))
			{
				tempword[ii]=tempword[ii].replaceAll("\\W","");     //replacing 'white-spaces' with 'space' 
				tempwords1[kk]=tempword[ii];
				kk++;
			}
			}
			String[] tempwords=new String[kk];
			for(int ii=0;ii<kk;ii++)
			{
			tempwords[ii]=tempwords1[ii];
			}
			for(int ii=0;ii<kk;ii++)
			{
			twodarray[i][ii]=tempwords[ii];
			}
		}
		
		document = document.toLowerCase();             //getting rid of case-sensitiveness in the given document
		String[] word = document.split(" ");           //use of 'Split function
		String[] words1 =new String[100000];
		int k=0;
		document=document.replaceAll("\t"," ");        //replacing the specified things(as done before) in the document
		for(int i=0;i<word.length;i++)
		{
		if(!word[i].equals("a") && !word[i].equals("an") && !word[i].equals("the") && !word[i].equals("this") && !word[i].equals("that") && !word[i].equals("and") && !word[i].equals("or") && !word[i].equals("is") && !word[i].equals("are") && !word[i].equals("then") && !word[i].equals("there") && !word[i].equals("they") && !word[i].equals("of") && !word[i].equals("on") && !word[i].equals("in") && !word[i].equals("to"))
		{
			word[i]=word[i].replaceAll("\\W","");
			words1[k]=word[i];
			k++;
			
		}
		}
		
		String[] words=new String[k];
		for(int i=0;i<k;i++){
		words[i]=words1[i];
		}
		String total = "";                     //string that contains the modified documents words in an order
		for (String i : words) {
			if( !total.contains( i ) )
				total = total + i + " ";
		}
		String[] totalarray = total.split(" ");       // using split function over an array that contains union of all the words over documents
		float tf = 0;
		int[] mfreq = new int[totalarray.length];
		for(int i=0;i<NoOfFiles;i++){
			int j=0;
			int m=0,tmp=0;
			while(twodarray[i][j] != null){
				for(int st=0;twodarray[i][st]!=null;st++)
				{  if(twodarray[i][j].equals(twodarray[i][st]))
                        tmp++;					
				}
				if(tmp>m)
					m=tmp;
				j += 1;
				
			}
		   mfreq[i]=m;                                               // calculating the maximum frequency for the statistics value calculation
		}
		float idf=0;                                                 //calculating tf-idf for the modified document
		float[][] multi = new float[NoOfFiles][totalarray.length];
		for(int j=0;j<NoOfFiles;j++){
			for( int i =0;i<totalarray.length;i++)
			{
				tf=TF(totalarray[i],twodarray[j],mfreq[j]);
				idf=IDF(totalarray[i],twodarray,NoOfFiles);
				multi[j][i]=tf*idf;
			}
		}
	for( int i=0;i<NoOfFiles;i++){                               //printing the 2-d array containing words and its statistics value
		for( int kk=0;kk<totalarray.length;kk++){
			System.out.printf("%f ",multi[i][kk]);
		}
		System.out.println();
	}
	}
	static void a(String str) {                               // a function to print a string wherever required
		System.out.println(str);

	}

}